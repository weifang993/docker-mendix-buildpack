/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/bs/currency",{HKD_displayName:"Honkon\u0161ki dolar",CHF_displayName:"\u0160vajcarski franak",CAD_displayName:"Kanadski dolar",CNY_displayName:"Kineski Juan Renminbi",AUD_displayName:"Australijski dolar",JPY_displayName:"Japanski jen",USD_displayName:"Ameri\u010dki dolar",GBP_displayName:"Britanska funta sterlinga",EUR_displayName:"Evro"});
