/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/mk/currency",{HKD_displayName:"\u0425\u043e\u043d\u0433\u043a\u043e\u043d\u0448\u043a\u0438 \u0434\u043e\u043b\u0430\u0440",CHF_displayName:"\u0428\u0432\u0430\u0458\u0446\u0430\u0440\u0441\u043a\u0438 \u0424\u0440\u0430\u043d\u043a",JPY_symbol:"JPY",CAD_displayName:"\u041a\u0430\u043d\u0430\u0434\u0441\u043a\u0438 \u0434\u043e\u043b\u0430\u0440",HKD_symbol:"HKD",CNY_displayName:"\u041a\u0438\u043d\u0435\u0441\u043a\u0438 \u0458\u0443\u0430\u043d",USD_symbol:"US$",AUD_displayName:"\u0410\u0432\u0441\u0442\u0440\u0430\u043b\u0438\u0441\u043a\u0438 \u0434\u043e\u043b\u0430\u0440",
JPY_displayName:"\u0408\u0430\u043f\u043e\u043d\u0441\u043a\u0438 \u0458\u0435\u043d",CAD_symbol:"CA$",USD_displayName:"\u0410\u043c\u0435\u0440\u0438\u043a\u0430\u043d\u0441\u043a\u0438 \u0434\u043e\u043b\u0430\u0440",CNY_symbol:"CNY",GBP_displayName:"\u0411\u0440\u0438\u0442\u0430\u043d\u0441\u043a\u0430 \u0424\u0443\u043d\u0442\u0430",GBP_symbol:"GBP",AUD_symbol:"AUD",EUR_displayName:"\u0415\u0432\u0440\u043e"});
