define(
//begin v1.x content
{
	"HKD_displayName": "Đô la Hồng Kông",
	"CHF_displayName": "Franc Thụy sĩ",
	"JPY_symbol": "JP¥",
	"CAD_displayName": "Đô la Canada",
	"HKD_symbol": "HK$",
	"CNY_displayName": "Nhân dân tệ",
	"USD_symbol": "US$",
	"AUD_displayName": "Đô la Australia",
	"JPY_displayName": "Yên Nhật",
	"CAD_symbol": "CA$",
	"USD_displayName": "Đô la Mỹ",
	"EUR_symbol": "€",
	"CNY_symbol": "CN¥",
	"GBP_displayName": "Bảng Anh",
	"GBP_symbol": "£",
	"AUD_symbol": "AU$",
	"EUR_displayName": "Euro"
}
//end v1.x content
);